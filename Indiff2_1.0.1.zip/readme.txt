Indifference: Part II
1.0.0

05.29 ~ 06.21

It's a map which is inspired by one of the best creators, Jesper the End's work, the Code.

Play the Code Series:
1. http://jespertheend.com/post/the-code
2. http://jespertheend.com/post/the-code-ii
3. http://jespertheend.com/post/the-code-iii
4. http://jespertheend.com/post/the-code-iv

Jesper the End's Youtube Channel:
https://www.youtube.com/user/jespertheend
https://www.youtube.com/user/jespertheend2

Map Settings:
Mode: Singleplayer recommended, if thou wantest to play with multiplayer thou shouldest to open the server with a LAN or bukkit without plugins or mods.
Spawnpoint: 0 50 0 [0.0]
Difficulty: Hard
Music: OFF
Perspective: First Person View

Map Creators:
DapurM
Muon

Special Thanks:
Jesper the End

I hope thou enjoyest this map.